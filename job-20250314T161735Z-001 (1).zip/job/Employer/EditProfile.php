<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Panel - Edit Profile</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Company Panel</h1>
            <p class="text-lg">
                Welcome, <?php echo htmlspecialchars($_SESSION['Name'], ENT_QUOTES, 'UTF-8'); ?>
            </p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Manage Job" => "ManageJob.php",
                    "Posted Jobs" => "PostJob.php",
                    "Application" => "Application.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Section -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Edit Profile</h2>
            <?php
            $ID = $_SESSION['ID'];
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "job1";
            $port = "3306"; 

            // Establish Connection with Database
            $conn = new mysqli($servername, $username, $password, $database, $port);
            // Specify the query to execute
            $sql = "SELECT * FROM Employer_Reg WHERE EmployerId='" . $ID . "'";
            // Execute query
            $result = $conn->query($sql);
            // Loop through each record 
            $row = $result->fetch_assoc();
            ?>
            <form method="post" action="UpdateProfile.php">
                <table class="table-auto w-full text-left border-collapse">
                    <tr>
                        <td class="py-2"><strong>Company ID:</strong></td>
                        <td class="py-2">
                            <input readonly name="txtId" type="text" id="txtId" value="<?php echo htmlspecialchars($row['EmployerId'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Company Name:</strong></td>
                        <td class="py-2">
                            <input name="txtName" type="text" id="txtName" value="<?php echo htmlspecialchars($row['CompanyName'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Contact Person:</strong></td>
                        <td class="py-2">
                            <input name="txtContact" type="text" id="txtContact" value="<?php echo htmlspecialchars($row['ContactPerson'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Address:</strong></td>
                        <td class="py-2">
                            <textarea name="txtAddress" id="txtAddress" cols="35" rows="3" class="border rounded-md p-2 w-1/2" required><?php echo htmlspecialchars($row['Address'], ENT_QUOTES, 'UTF-8'); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>City:</strong></td>
                        <td class="py-2">
                            <input name="txtCity" type="text" id="txtCity" value="<?php echo htmlspecialchars($row['City'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Email:</strong></td>
                        <td class="py-2">
                            <input name="txtEmail" type="text" id="txtEmail" value="<?php echo htmlspecialchars($row['Email'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Mobile:</strong></td>
                        <td class="py-2">
                            <input name="txtMobile" type="text" id="txtMobile" value="<?php echo htmlspecialchars($row['Mobile'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Area of Work:</strong></td>
                        <td class="py-2">
                            <input name="txtArea" type="text" id="txtArea" value="<?php echo htmlspecialchars($row['Area_Work'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>User Name:</strong></td>
                        <td class="py-2">
                            <input name="txtUser" type="text" id="txtUser" value="<?php echo htmlspecialchars($row['UserName'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Password:</strong></td>
                        <td class="py-2">
                            <input name="txtPassword" type="password" id="txtPassword" value="<?php echo htmlspecialchars($row['Password'], ENT_QUOTES, 'UTF-8'); ?>" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <input type="submit" name="button" id="button" value="Submit" class="bg-blue-600 text-white rounded-md p-2 hover:bg-blue-700 cursor-pointer" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
