<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Panel - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Company Panel</h1>
            <p class="text-lg">
                <?php 
                // Ensuring session data is safe
                echo "Welcome " . htmlspecialchars($_SESSION['Name'], ENT_QUOTES, 'UTF-8');
                ?>
            </p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Manage Job" => "ManageJob.php",
                    "Posted Jobs" => "PostJob.php",
                    "Application" => "Application.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Section -->
    <main class="container mx-auto px-4 py-8 flex-grow">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">Welcome To Control Panel</h2>
            <p class="text-gray-700 text-lg leading-relaxed mb-4">
                As you step into our Placement Cell Dashboard, you are greeted with a gateway to a diverse talent pool and a plethora of opportunities waiting to be explored. We extend our warmest welcome to you and are thrilled to embark on this journey of collaboration and partnership together.
            </p>
            <p class="text-gray-700 text-lg leading-relaxed mb-4">
                Our Placement Cell Dashboard serves as a centralized hub designed to facilitate seamless recruitment processes and foster meaningful connections between your esteemed organization and our talented pool of students. With user-friendly interfaces and robust features, navigating through our dashboard promises to be an intuitive and rewarding experience.
            </p>
            <p class="text-gray-700 text-lg leading-relaxed mb-4">
                Within this dashboard, you'll find a myriad of tools and resources tailored to meet your recruitment needs. From accessing detailed student profiles and resumes to scheduling interviews and managing recruitment events, every aspect of the hiring process is meticulously curated to ensure efficiency and success.
            </p>
            <p class="text-gray-700 text-lg leading-relaxed">
                At the heart of our Placement Cell lies a commitment to excellence, integrity, and mutual growth. We understand the pivotal role that your organization plays in shaping the future of our students, and we are dedicated to facilitating a seamless recruitment experience that aligns with your objectives and values. Welcome to your Placement Cell —where talent meets opportunity!
            </p>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
