<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Company Panel</h1>
            <p class="text-lg">
                Welcome, <?php echo htmlspecialchars($_SESSION['Name'], ENT_QUOTES, 'UTF-8'); ?>
            </p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Manage Job" => "ManageJob.php",
                    "Posted Jobs" => "PostJob.php",
                    "Application" => "Application.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Section -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Posted Jobs</h2>
            <table class="min-w-full bg-white border border-gray-300">
                <thead>
                    <tr class="bg-blue-600 text-white">
                        <th class="py-2 px-4">Id</th>
                        <th class="py-2 px-4">Job Title</th>
                        <th class="py-2 px-4">Vacancy</th>
                        <th class="py-2 px-4">Qualification</th>
                        <th class="py-2 px-4">Description</th>
                        <th class="py-2 px-4">Update</th>
                        <th class="py-2 px-4">Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Establish Connection with Database
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "job1";
                    $port = "3306";

                    $conn = new mysqli($servername, $username, $password, $database, $port);
                    $sql = "SELECT * FROM job_Master WHERE CompanyName='" . $_SESSION['Name'] . "'";
                    // Execute query
                    $result = $conn->query($sql);
                    // Loop through each record 
                    while ($row = $result->fetch_assoc()) {
                        $Id = $row['JobId'];
                        $JobTitle = $row['JobTitle'];
                        $Vacancy = $row['Vacancy'];
                        $MinQualification = $row['MinQualification'];
                        $Description = $row['Description'];
                    ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo htmlspecialchars($Id, ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="py-2 px-4"><?php echo htmlspecialchars($JobTitle, ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="py-2 px-4"><?php echo htmlspecialchars($Vacancy, ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="py-2 px-4"><?php echo htmlspecialchars($MinQualification, ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="py-2 px-4"><?php echo htmlspecialchars($Description, ENT_QUOTES, 'UTF-8'); ?></td>
                        <td class="py-2 px-4"><a href="testmanage.php?JobId=<?php echo $Id; ?>" class="text-blue-600 hover:underline">Update</a></td>
                        <td class="py-2 px-4"><a href="DeleteJob.php?JobId=<?php echo $Id; ?>" class="text-red-600 hover:underline">Delete</a></td>
                    </tr>
                    <?php
                    }
                    // Retrieve Number of records returned
                    $records = $result->num_rows;
                    ?>
                    <tr>
                        <td colspan="6" class="py-2 px-4"><strong><?php echo "Total " . $records . " Records"; ?></strong></td>
                    </tr>
                    <?php
                    // Close the connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div> <!-- /content -->
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

