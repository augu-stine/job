<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Panel - Manage Job</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Company Panel</h1>
            <p class="text-lg">
                Welcome, <?php echo htmlspecialchars($_SESSION['Name'], ENT_QUOTES, 'UTF-8'); ?>
            </p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Manage Job" => "ManageJob.php",
                    "Posted Jobs" => "PostJob.php",
                    "Application" => "Application.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Section -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Manage Job</h2>
            <form id="form1" method="post" action="InsertJob.php">
                <table class="table-auto w-full text-left border-collapse">
                    <tr>
                        <td class="py-2"><strong>Job Title:</strong></td>
                        <td class="py-2">
                            <input type="text" name="txtTitle" id="txtTitle" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Total Vacancy:</strong></td>
                        <td class="py-2">
                            <input type="text" name="txtTotal" id="txtTotal" class="border rounded-md p-2 w-1/2" required />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Qualification:</strong></td>
                        <td class="py-2">
                            <select name="cmbQual" id="cmbQual" class="border rounded-md p-2 w-1/2">
                                <option value="B.C.A">B.C.A</option>
                                <option value="M.C.A">M.C.A</option>
                                <option value="B.Sc.I.T">B.Sc.I.T</option>
                                <option value="B.Sc.C.S">B.Sc.C.S</option>
                                <option value="M.Sc.I.T">M.Sc.I.T</option>
                                <option value="M.Sc.C.S">M.Sc.C.S</option>
                                <option value="M.B.A">M.B.A</option>
                                <option value="B.B.A">B.B.A</option>
                                <option value="Other">Other</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Other:</strong></td>
                        <td class="py-2">
                            <input type="text" name="txtOther" id="txtOther" class="border rounded-md p-2 w-1/2" />
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Description:</strong></td>
                        <td class="py-2">
                            <textarea name="txtDesc" id="txtDesc" cols="25" rows="3" class="border rounded-md p-2 w-1/2" required></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td>
                            <input type="submit" name="button" id="button" value="Submit" class="bg-blue-600 text-white rounded-md p-2 hover:bg-blue-700 cursor-pointer" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
