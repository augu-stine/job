<?php 
session_start();

// Include PHPMailer classes at the top
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require './vendor/autoload.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if POST variables are set
if (isset($_POST['JobId'], $_POST['JobSeekId'], $_POST['AppId'], $_POST['status'], $_POST['txtDesc'])) {
    $JobId = $_POST['JobId'];
    $JobSeekId = $_POST['JobSeekId'];
    $AppId = $_POST['AppId'];
    $Status = $_POST['status'];
    $Description = $_POST['txtDesc'];

    // Update Application_Master
    $sql = "UPDATE Application_Master SET Status=?, Description=? WHERE ApplicationId=? AND JobId=? AND JobSeekId=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssiss", $Status, $Description, $AppId, $JobId, $JobSeekId);
    
    if (!$stmt->execute()) {
        die("Error updating record: " . $stmt->error);
    }

    // Send email
    $sql = "SELECT Email FROM jobseeker_reg WHERE JobSeekId=(SELECT JobSeekId FROM Application_Master WHERE ApplicationId=?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $AppId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $recipient_email = $row['Email'];

    $sql = "SELECT CompanyName FROM job_master WHERE JobId=(SELECT JobId FROM Application_Master WHERE ApplicationId=?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $AppId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $sender_name = $row['CompanyName'];
    $sender_email = "augu414@gmail.com";
    $subject = "Information on your placement application";
    $body = "You have been selected for " . $Status . ". Further details are given below:\n" . $Description;

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->SMTPDebug = 0; // Set to 2 for debugging information
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'augu414@gmail.com'; // Replace with your SMTP username
      $mail->Password = 'bnib ctxm hmac dmos'; // Replace with your SMTP password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Recipients
        $mail->setFrom($sender_email, $sender_name);
        $mail->addAddress($recipient_email, 'placement cell');

        // Content
        $mail->isHTML(false);
        $mail->Subject = $subject;
        $mail->Body = $body;

        $mail->send();
        
    } catch (Exception $e) {
        echo "Something went wrong. Mailer Error: {$mail->ErrorInfo}";
    }

    // Update vacancy if necessary
    $sql = "SELECT Vacancy FROM job_master WHERE JobId=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $JobId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $vacancy = $row['Vacancy'];

    if ($Status == 'Confirm' && $vacancy != 0) {
        $vacancy--;
        $sql2 = "UPDATE job_master SET Vacancy=? WHERE JobId=?";
        $stmt2 = $conn->prepare($sql2);
        $stmt2->bind_param("ii", $vacancy, $JobId);
        $stmt2->execute();

        echo '<script type="text/javascript">alert("Sent Successfully"); window.location=\'Application.php\';</script>';
    } elseif ($vacancy == 0) {
        echo '<script type="text/javascript">alert("Vacancy is full"); window.location=\'Application.php\';</script>';
    } else {
        echo '<script type="text/javascript">alert("Sent Successfully"); window.location=\'Application.php\';</script>';
    }
} else {
    echo '<script type="text/javascript">alert("Invalid input data."); window.location=\'Application.php\';</script>';
}

$conn->close();
?>
