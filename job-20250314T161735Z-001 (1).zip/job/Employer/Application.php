<?php
if (!isset($_SESSION)) {
    session_start();
}

function getSQLValueString($mysqli, $theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
    $theValue = $mysqli->real_escape_string($theValue);

    switch ($theType) {
        case "text":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;    
        case "long":
        case "int":
            $theValue = ($theValue != "") ? intval($theValue) : "NULL";
            break;
        case "double":
            $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
            break;
        case "date":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;
        case "defined":
            $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
            break;
    }
    return $theValue;
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306"; 

$conn = new mysqli($servername, $username, $password, $database, $port);

$colname_Recordset1 = "-1";
if (isset($_SESSION['Name'])) {
    $colname_Recordset1 = $_SESSION['Name'];
}

$query_Recordset1 = sprintf("SELECT JobId, JobTitle FROM job_master WHERE CompanyName = %s", getSQLValueString($conn, $colname_Recordset1, "text"));
$Recordset1 = $conn->query($query_Recordset1);
$row_Recordset1 = $Recordset1->fetch_assoc();
$totalRows_Recordset1 =  $Recordset1->num_rows;

$query_Recordset2 = "SELECT application_master.ApplicationId, application_master.Status, jobseeker_reg.JobSeekerName, jobseeker_reg.City, jobseeker_reg.Email, application_master.JobId FROM application_master, jobseeker_reg WHERE jobseeker_reg.JobSeekId=application_master.JobSeekId";
$Recordset2 = $conn->query($query_Recordset2);
$row_Recordset2 = $Recordset2->fetch_assoc();
$totalRows_Recordset2 = $Recordset2->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Applications</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header Section -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Company Applications</h1>
            <p class="text-lg">Welcome, <?php echo htmlspecialchars($_SESSION['Name'], ENT_QUOTES, 'UTF-8'); ?></p>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Manage Job" => "ManageJob.php",
                    "Posted Jobs" => "PostJob.php",
                    "Application" => "Application.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Section -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Application Management</h2>
            <form class="mb-4" id="form1" method="post" action="Application.php">
                <label class="block mb-2">
                    <strong>Select Job Title:</strong>
                    <select class="block border rounded p-2 w-1/4" name="cmbTitle" id="cmbTitle">
                        <?php
                        do {  
                        ?>
                        <option value="<?php echo htmlspecialchars($row_Recordset1['JobId'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($row_Recordset1['JobTitle'], ENT_QUOTES, 'UTF-8'); ?></option>
                        <?php
                        } while ($row_Recordset1 = $Recordset1->fetch_assoc());
                        ?>
                    </select>
                </label>
                <label>
                    <input class="bg-blue-600 text-white rounded py-2 px-4" type="submit" name="button" id="button" value="View" />
                </label>
            </form>

            <?php 
            if (isset($_POST['cmbTitle'])) {
                $Title = $_POST['cmbTitle'];
                $sql = "SELECT application_master.ApplicationId, application_master.Status, jobseeker_reg.JobSeekerName, jobseeker_reg.Qualification, jobseeker_reg.Email, jobseeker_reg.JobSeekId, application_master.JobId FROM application_master, jobseeker_reg WHERE jobseeker_reg.JobSeekId=application_master.JobSeekId AND application_master.JobId='" . $Title . "'";
                // Execute query
                $result = $conn->query($sql);
                $records = $result->num_rows;

                if ($records > 0) {
            ?>
                <br>
                <table class="min-w-full border border-gray-300">
                    <thead>
                        <tr class="bg-blue-600 text-white">
                            <th class="py-2 px-4"><strong>Id</strong></th>
                            <th class="py-2 px-4"><strong>Name</strong></th>
                            <th class="py-2 px-4"><strong>Course</strong></th>
                            <th class="py-2 px-4"><strong>Email</strong></th>
                            <th class="py-2 px-4"><strong>Status</strong></th>
                            <th class="py-2 px-4"><strong>View & Send</strong></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($row = $result->fetch_assoc()) {
                            $Id = $row['ApplicationId'];
                            $Status = $row['Status'];
                            $JobSeekerName = $row['JobSeekerName'];
                            $City = $row['Qualification'];
                            $Email = $row['Email'];
                            $JobSeekId = $row['JobSeekId'];
                        ?>
                        <tr>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($Id, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($JobSeekerName, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($City, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($Email, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border px-4 py-2"><?php echo htmlspecialchars($Status, ENT_QUOTES, 'UTF-8'); ?></td>
                            <td class="border px-4 py-2"><a href="ViewBiodata.php?JobSeekId=<?php echo htmlspecialchars($JobSeekId, ENT_QUOTES, 'UTF-8'); ?>&AppId=<?php echo htmlspecialchars($Id, ENT_QUOTES, 'UTF-8'); ?>&JobId=<?php echo htmlspecialchars($Title, ENT_QUOTES, 'UTF-8'); ?>&Status=<?php echo htmlspecialchars($Status, ENT_QUOTES, 'UTF-8'); ?>" class="text-blue-600">View</a></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
                <?php
                } else {
                    echo "<br>No records found.";
                }
                // Close the connection
                $conn->close();
            }
            ?>
        </div> <!-- /content -->
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
