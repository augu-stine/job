<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$JobSeekId = $_GET['JobSeekId'] ?? '';
$JobId = $_GET['JobId'] ?? '';
$AppId = $_GET['AppId'] ?? '';
$Status = $_GET['Status'] ?? '';

// Fetch applicant data
$sql = "SELECT * FROM JobSeeker_Reg WHERE JobSeekId = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $JobSeekId);
$stmt->execute();
$result = $stmt->get_result();
$applicant = $result->fetch_assoc();

// Fetch education data
$sql = "SELECT * FROM JobSeeker_Education WHERE JobSeekId = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $JobSeekId);
$stmt->execute();
$education_result = $stmt->get_result();
$education = $education_result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Applicant - Company Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen">
    <header class="bg-blue-600 text-white shadow">
        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <h1 class="text-3xl font-bold">Company Panel</h1>
        </div>
    </header>

    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div class="px-4 py-6 sm:px-0">
            <div class="bg-white shadow overflow-hidden sm:rounded-lg">
                <div class="px-4 py-5 sm:px-6">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Applicant Details
                    </h2>
                </div>
                <div class="border-t border-gray-200 px-4 py-5 sm:p-0">
                    <dl class="sm:divide-y sm:divide-gray-200">
                        <?php foreach ($applicant as $key => $value): ?>
                            <div class="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                                <dt class="text-sm font-medium text-gray-500"><?php echo htmlspecialchars($key); ?></dt>
                                <dd class="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                                    <?php if ($key === 'Resume'): ?>
                                        <a href="../upload/<?php echo htmlspecialchars($value); ?>" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:text-blue-800">
                                            View Resume
                                        </a>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($value); ?>
                                    <?php endif; ?>
                                </dd>
                            </div>
                        <?php endforeach; ?>
                    </dl>
                </div>
            </div>

            <div class="mt-8 bg-white shadow overflow-hidden sm:rounded-lg">
                <div class="px-4 py-5 sm:px-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        Educational Qualifications
                    </h3>
                </div>
                <div class="border-t border-gray-200">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Degree</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Institution</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Year of Passing</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($education as $edu): ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($edu['Degree']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($edu['University']); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900"><?php echo htmlspecialchars($edu['PassingYear']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <form action="CallLatter.php" method="post" class="mt-8">
                <input type="hidden" name="JobId" value="<?php echo htmlspecialchars($JobId); ?>">
                <input type="hidden" name="JobSeekId" value="<?php echo htmlspecialchars($JobSeekId); ?>">
                <input type="hidden" name="AppId" value="<?php echo htmlspecialchars($AppId); ?>">

                <div class="mt-4">
                    <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                    <select name="status" id="status" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option value="Confirm">Confirm</option>
                        <option value="Reject">Reject</option>
                    </select>
                </div>

                <div class="mt-4">
                    <label for="txtDesc" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="txtDesc" id="txtDesc" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
                </div>

                <button type="submit" class="mt-6 inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Send Notification
                </button>
            </form>
            <div class="mt-8 text-center">
                <a href="Application.php" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-gray-600 hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                    Back to Applications
                </a>
            </div>
        </div>
    </main>
</body>
</html>
