<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306"; // Specify the port number
?>