<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Cell - Company Registration</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:400,700&display=swap');
        body {
            font-family: 'Assistant', sans-serif;
            background: linear-gradient(45deg, #3498db, #8e44ad);
        }
    </style>
</head>
<body class="min-h-screen py-12">
    <div class="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">PLACEMENT CELL</h1>
        <h2 class="text-2xl font-semibold mb-6 text-center text-gray-700">Company Registration Form</h2>

        <form action="EmployeInsert.php" method="post" enctype="multipart/form-data" id="form2" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="txtName" class="block text-sm font-medium text-gray-700">Company Name</label>
                    <input type="text" name="txtName" id="txtName" placeholder="Enter Company Name" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtPerson" class="block text-sm font-medium text-gray-700">Contact Person</label>
                    <input type="text" name="txtPerson" id="txtPerson" placeholder="Enter Contact Person" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtAddress" class="block text-sm font-medium text-gray-700">Address</label>
                    <textarea name="txtAddress" id="txtAddress" placeholder="Enter Address" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
                </div>
                <div>
                    <label for="txtCity" class="block text-sm font-medium text-gray-700">City</label>
                    <input type="text" name="txtCity" id="txtCity" placeholder="Enter City" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtEmail" class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="txtEmail" id="txtEmail" placeholder="Enter Email" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtMobile" class="block text-sm font-medium text-gray-700">Mobile</label>
                    <input type="text" name="txtMobile" id="txtMobile" placeholder="Enter Mobile Number" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtAreaWork" class="block text-sm font-medium text-gray-700">Area of Work</label>
                    <input type="text" name="txtAreaWork" id="txtAreaWork" placeholder="Enter Area of Work" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtUserName" class="block text-sm font-medium text-gray-700">Username</label>
                    <input type="text" name="txtUserName" id="txtUserName" placeholder="Enter Username" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtPassword" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="txtPassword" id="txtPassword" placeholder="Enter Password" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="CPassword" class="block text-sm font-medium text-gray-700">Confirm Password</label>
                    <input type="password" name="CPassword" id="CPassword" placeholder="Confirm Password" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="cmbQue" class="block text-sm font-medium text-gray-700">Security Question</label>
                    <select name="cmbQue" id="cmbQue" class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option>What is Your Pet Name?</option>
                        <option selected="selected">Who is Your Favourite Person?</option>
                        <option>What is the Name of Your First School?</option>
                    </select>
                </div>
                <div>
                    <label for="txtAnswer" class="block text-sm font-medium text-gray-700">Answer</label>
                    <input type="text" name="txtAnswer" id="txtAnswer" placeholder="Enter Answer" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
            </div>
            <div class="flex justify-center mt-6">
                <button type="submit" class="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">Register</button>
            </div>
        </form>

        <div class="mt-6 text-center">
            <a href="cmpylogin.php" class="text-blue-500 hover:underline">Already have an account? Login here</a>
        </div>
        
        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-blue-600 hover:text-blue-800">Back to Home</a>
        </div>
    </div>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Assistant', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>
