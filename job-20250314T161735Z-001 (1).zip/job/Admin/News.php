<?php
session_start();
// Check if user is logged in and is an admin


$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM News_Master ORDER BY NewsDate DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Management - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Admin Panel</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "User" => "User.php",
                    "Manage Students" => "ManageJob.php",
                    "Manage Companies" => "ManageEmployer.php",
                    "Reports" => "report.php",
                    "News" => "News.php",
                    "Feedback" => "Feedback.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">News Management</h2>
            
            <form id="form1" method="post" action="InsertNews.php" class="mb-8">
                <div class="mb-4">
                    <label for="txtNews" class="block text-sm font-medium text-gray-700">News:</label>
                    <textarea name="txtNews" id="txtNews" rows="2" class="mt-1 block w-1/4 h-12 bg-gray-200 text-gray-900 border border-gray-600 rounded-md shadow-sm focus:border-blue-400 focus:ring focus:ring-blue-200 focus:ring-opacity-50" required></textarea>
                </div>
                <div class="mb-4">
                    <label for="txtDate" class="block text-sm font-medium text-gray-700">News Date:</label>
                    <input type="date" name="txtDate" id="txtDate" class="mt-1 block w-1/4 bg-gray-200 text-gray-900 border border-gray-600 rounded-md shadow-sm focus:border-blue-400 focus:ring focus:ring-blue-200 focus:ring-opacity-50" required>
                </div>
                <button type="submit" name="button" id="button" class="px-3 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    Submit
                </button>
            </form>

            <h3 class="text-xl font-semibold mb-4">News List</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="py-2 px-4 border-b text-left">Id</th>
                            <th class="py-2 px-4 border-b text-left">News</th>
                            <th class="py-2 px-4 border-b text-left">Date</th>
                            <th class="py-2 px-4 border-b text-left">Edit</th>
                            <th class="py-2 px-4 border-b text-left">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while($row = $result->fetch_assoc()) {
                            echo "<tr class='hover:bg-gray-50'>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['NewsId']) . "</td>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['News']) . "</td>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['NewsDate']) . "</td>";
                            echo "<td class='py-2 px-4 border-b'><a href='EditNews.php?NewsId=" . $row['NewsId'] . "' class='text-blue-600 hover:underline'>Edit</a></td>";
                            echo "<td class='py-2 px-4 border-b'><a href='DeleteNews.php?NewsId=" . $row['NewsId'] . "' class='text-red-600 hover:underline'>Delete</a></td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <p class="mt-4 text-gray-600">
                <?php echo "Total " . $result->num_rows . " Records"; ?>
            </p>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Admin Panel. All rights reserved.</p>
        </div>
    </footer>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'georgia': ['Georgia', 'serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
