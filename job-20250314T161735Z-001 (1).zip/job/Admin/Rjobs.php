<?php
session_start();
// Check if user is logged in
if(!isset($_SESSION['UserType'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Listings - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Portal</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="report.php" class="hover:text-blue-300">Back</a></li>
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
              
                <li><a href="logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Job Listings</h2>
            
            <form method="post" class="mb-6">
                <div class="flex items-center space-x-4">
                    <select name="qual" id="qual" class="border rounded-md p-2">
                        <option value="">Select Company</option>
                        <?php
                        $sql = "SELECT DISTINCT CompanyName FROM job_master";
                        $result = $conn->query($sql);
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . htmlspecialchars($row['CompanyName']) . "'>" . htmlspecialchars($row['CompanyName']) . "</option>";
                        }
                        ?>
                    </select>
                    <button type="submit" name="s1" id="s1" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Filter</button>
                </div>
            </form>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="py-2 px-4 border-b text-left">Company</th>
                            <th class="py-2 px-4 border-b text-left">Job</th>
                            <th class="py-2 px-4 border-b text-left">Vacancy</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if(isset($_POST['s1'])) {
                            $qual = $conn->real_escape_string($_POST['qual']);
                            $sql = "SELECT * FROM job_master WHERE CompanyName='$qual'";
                        } else {
                            $sql = "SELECT * FROM job_master";
                        }
                        $result = $conn->query($sql);
                        while($row = $result->fetch_assoc()) {
                            echo "<tr class='hover:bg-gray-50'>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['CompanyName']) . "</td>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['JobTitle']) . "</td>";
                            echo "<td class='py-2 px-4 border-b'>" . htmlspecialchars($row['Vacancy']) . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <p class="mt-4 text-gray-600">
                <?php echo "Total " . $result->num_rows . " Records"; ?>
            </p>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Portal. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // You can add any additional JavaScript here if needed
    </script>
</body>
</html>

<?php
$conn->close();
?>