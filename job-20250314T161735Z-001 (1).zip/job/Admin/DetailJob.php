<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Student Details</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Admin Panel - Student Details</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                  "Home" => "index.php",
        "User" => "User.php",
        "Manage Students" => "ManageJob.php",
        "Manage Companies" => "ManageEmployer.php",
        "Reports"=>"report.php",
        "News"=>"News.php",
        "Feedback"=>"Feedback.php",
        "Logout"=>"Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Student Details</h2>

            <?php
            $ID = $_GET['JobId'];
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "job1";
            $port = "3306";

            // Establish connection with database
            $conn = new mysqli($servername, $username, $password, $database, $port);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Specify the query to execute
            $sql = "SELECT * FROM JobSeeker_Reg WHERE JobSeekId='" . $ID . "'";
            $result = $conn->query($sql);

            if ($row = $result->fetch_assoc()) {
            ?>

            <table class="table-auto w-full text-left border-collapse">
                <tr class="border-b">
                    <td class="py-2"><strong>Id:</strong></td>
                    <td class="py-2"><?php echo $row['JobSeekId']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Name:</strong></td>
                    <td class="py-2"><?php echo $row['JobSeekerName']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Address:</strong></td>
                    <td class="py-2"><?php echo $row['Address']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>City:</strong></td>
                    <td class="py-2"><?php echo $row['City']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Email:</strong></td>
                    <td class="py-2"><?php echo $row['Email']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Mobile:</strong></td>
                    <td class="py-2"><?php echo $row['Mobile']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Highest Qualification:</strong></td>
                    <td class="py-2"><?php echo $row['Qualification']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>No. of Arrears:</strong></td>
                    <td class="py-2"><?php echo $row['Supply']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Gender:</strong></td>
                    <td class="py-2"><?php echo $row['Gender']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Birth Date:</strong></td>
                    <td class="py-2"><?php echo $row['BirthDate']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Resume:</strong></td>
                    <td class="py-2"><a href="../upload/<?php echo $row['Resume']; ?>" target="_blank" class="text-blue-500 hover:underline"><strong>View</strong></a></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <a href="ApprovJob.php?JobId=<?php echo $row['JobSeekId']; ?>" class="text-green-600 hover:underline"><strong>Approve Student</strong></a>
                        |
                        <a href="DenyJob.php?JobId=<?php echo $row['JobSeekId']; ?>" class="text-red-600 hover:underline"><strong>Delete Student</strong></a>
                    </td>
                </tr>
            </table>

            <?php
            } else {
                echo "<p>No student data found.</p>";
            }

            $conn->close();
            ?>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Admin Panel. All rights reserved.</p>
        </div>
    </footer>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'georgia': ['Georgia', 'serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>
