<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT FeedbackId, Feedback, FeedbakDate, JobSeekerName 
        FROM Feedback, JobSeeker_Reg 
        WHERE Feedback.JobSeekId = JobSeeker_Reg.JobSeekId 
        ORDER BY FeedbakDate DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Feedback</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <!-- Header -->
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Admin Panel</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="User.php" class="hover:text-blue-300">User</a></li>
                <li><a href="ManageJob.php" class="hover:text-blue-300">Manage Students</a></li>
                <li><a href="ManageEmployer.php" class="hover:text-blue-300">Manage Companies</a></li>
                <li><a href="report.php" class="hover:text-blue-300">Reports</a></li>
                <li><a href="News.php" class="hover:text-blue-300">News</a></li>
                <li><a href="Feedback.php" class="hover:text-blue-300">Feedback</a></li>
                <li><a href="Logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Feedback Management</h2>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="py-2 px-4 border-b text-left">Id</th>
                            <th class="py-2 px-4 border-b text-left">Job Seeker Name</th>
                            <th class="py-2 px-4 border-b text-left">Feedback</th>
                            <th class="py-2 px-4 border-b text-left">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while($row = $result->fetch_assoc()) {
                            echo "<tr class='hover:bg-gray-50'>";
                            echo "<td class='py-2 px-4 border-b text-gray-700'>" . htmlspecialchars($row['FeedbackId']) . "</td>";
                            echo "<td class='py-2 px-4 border-b text-gray-700'>" . htmlspecialchars($row['JobSeekerName']) . "</td>";
                            echo "<td class='py-2 px-4 border-b text-gray-700'>" . htmlspecialchars($row['Feedback']) . "</td>";
                            echo "<td class='py-2 px-4 border-b text-gray-700'>" . htmlspecialchars($row['FeedbakDate']) . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <p class="mt-4 text-gray-600">
                <?php echo "Total " . $result->num_rows . " Records"; ?>
            </p>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Admin Panel. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>

<?php
$conn->close();
?>
