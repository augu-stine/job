<?php
session_start();
// Check if user is logged in


$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $database, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getCompanies($conn) {
    $sql = "SELECT DISTINCT CompanyName FROM job_master";
    $result = $conn->query($sql);
    $companies = [];
    while ($row = $result->fetch_assoc()) {
        $companies[] = $row['CompanyName'];
    }
    return $companies;
}

function getCourses($conn) {
    $sql = "SELECT DISTINCT j.Qualification FROM jobseeker_reg AS j, application_master AS a WHERE a.JobSeekId = j.JobSeekId";
    $result = $conn->query($sql);
    $courses = [];
    while ($row = $result->fetch_assoc()) {
        $courses[] = $row['Qualification'];
    }
    return $courses;
}

function getApplications($conn, $company = '', $course = '') {
    $sql = "SELECT s.jobSeekerName, s.Qualification, j.CompanyName, j.JobTitle 
            FROM jobseeker_reg AS s 
            JOIN application_master AS a ON a.JobSeekId = s.JobSeekId 
            JOIN job_master AS j ON a.JobId = j.JobId 
            WHERE a.Status = 'Confirm'";
    
    $params = [];
    $types = "";

    if (!empty($company)) {
        $sql .= " AND j.CompanyName = ?";
        $params[] = $company;
        $types .= "s";
    }
    if (!empty($course)) {
        $sql .= " AND s.Qualification = ?";
        $params[] = $course;
        $types .= "s";
    }
    
    $sql .= " ORDER BY s.jobSeekerName";
    
    $stmt = $conn->prepare($sql);
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $applications = [];
    while ($row = $result->fetch_assoc()) {
        $applications[] = $row;
    }
    return $applications;
}

$companies = getCompanies($conn);
$courses = getCourses($conn);

$selectedCompany = $_POST['qual'] ?? '';
$selectedCourse = $_POST['cor'] ?? '';

if (isset($_POST['s1']) || isset($_POST['s2'])) {
    $applications = getApplications($conn, $selectedCompany, $selectedCourse);
} else {
    $applications = getApplications($conn);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Status - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="report.php" class="hover:text-blue-300">Back</a></li>
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Application Status</h2>
            
            <form method="post" class="mb-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="qual" class="block text-sm font-medium text-gray-700 mb-1">Select Company</label>
                        <select name="qual" id="qual" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="">All Companies</option>
                            <?php foreach ($companies as $company): ?>
                                <option value="<?= htmlspecialchars($company) ?>" <?= $selectedCompany === $company ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($company) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="cor" class="block text-sm font-medium text-gray-700 mb-1">Select Course</label>
                        <select name="cor" id="cor" class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
                            <option value="">All Courses</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?= htmlspecialchars($course) ?>" <?= $selectedCourse === $course ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($course) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="mt-4 flex justify-end space-x-4">
                    <button type="submit" name="s1" class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Filter by Company
                    </button>
                    <button type="submit" name="s2" class="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2">
                        Filter by Course
                    </button>
                    <button type="submit" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2">
                        Reset
                    </button>
                </div>
            </form>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="py-2 px-4 border-b text-left">Name</th>
                            <th class="py-2 px-4 border-b text-left">Company Name</th>
                            <th class="py-2 px-4 border-b text-left">Post</th>
                            <th class="py-2 px-4 border-b text-left">Course</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $application): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($application['jobSeekerName']) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($application['CompanyName']) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($application['JobTitle']) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($application['Qualification']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <p class="mt-4 text-gray-600">
                Total <?= count($applications) ?> Records
            </p>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Student Portal. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>