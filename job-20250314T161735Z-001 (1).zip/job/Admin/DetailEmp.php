<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Details - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Admin Panel - Employer Details</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
        "User" => "User.php",
        "Manage Students" => "ManageJob.php",
        "Manage Companies" => "ManageEmployer.php",
        "Reports"=>"report.php",
        "News"=>"News.php",
        "Feedback"=>"Feedback.php",
        "Logout"=>"Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Employer Details</h2>

            <?php
            $ID = $_GET['EmpId'];
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "job1";
            $port = "3306";

            // Establish Connection with Database
            $conn = new mysqli($servername, $username, $password, $database, $port);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Execute query
            $sql = "SELECT * FROM Employer_Reg WHERE EmployerId ='" . $ID . "'";
            $result = $conn->query($sql);

            // Display employer data
            if ($row = $result->fetch_assoc()) {
            ?>
            
            <table class="table-auto w-full text-left border-collapse">
                <tr class="border-b">
                    <td class="py-2"><strong>ID:</strong></td>
                    <td class="py-2"><?php echo $row['EmployerId']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Company Name:</strong></td>
                    <td class="py-2"><?php echo $row['CompanyName']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Contact Person:</strong></td>
                    <td class="py-2"><?php echo $row['ContactPerson']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Address:</strong></td>
                    <td class="py-2"><?php echo $row['Address']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>City:</strong></td>
                    <td class="py-2"><?php echo $row['City']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Email:</strong></td>
                    <td class="py-2"><?php echo $row['Email']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Mobile:</strong></td>
                    <td class="py-2"><?php echo $row['Mobile']; ?></td>
                </tr>
                <tr class="border-b">
                    <td class="py-2"><strong>Area of Work:</strong></td>
                    <td class="py-2"><?php echo $row['Area_Work']; ?></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <a href="ApprovEmp.php?EmpId=<?php echo $row['EmployerId']; ?>" class="text-blue-600 hover:underline"><strong>Approve Employer</strong></a> |
                        <a href="DenyEmp.php?EmpId=<?php echo $row['EmployerId']; ?>" class="text-red-600 hover:underline"><strong>Deny Employer</strong></a>
                    </td>
                </tr>
            </table>

            <?php
            } else {
                echo "<p>No employer data found.</p>";
         
            }