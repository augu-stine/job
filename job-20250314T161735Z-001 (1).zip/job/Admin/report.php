<?php
session_start();
// Check if user is logged in and is an admin

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Georgia&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
        .font-georgia {
            font-family: 'Georgia', serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Admin Panel</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="User.php" class="hover:text-blue-300">User</a></li>
                <li><a href="ManageJob.php" class="hover:text-blue-300">Manage Students</a></li>
                <li><a href="ManageEmployer.php" class="hover:text-blue-300">Manage Companies</a></li>
                <li><a href="report.php" class="hover:text-blue-300">Reports</a></li>
                <li><a href="News.php" class="hover:text-blue-300">News</a></li>
                <li><a href="Feedback.php" class="hover:text-blue-300">Feedback</a></li>
                <li><a href="Logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Reports</h2>
            <h4 class="text-xl mb-4 font-georgia">Welcome aboard, and happy reporting!</h4>
            
            <div class="space-y-6">
                <div class="bg-gray-50 p-4 rounded-md">
                    <h3 class="text-lg font-semibold mb-2">Student Placement Report</h3>
                    <p class="mb-2">View detailed statistics on student placements.</p>
                    <a href="Rstudents.php" class="text-blue-600 hover:underline">Generate Report</a>
                </div>

                <div class="bg-gray-50 p-4 rounded-md">
                    <h3 class="text-lg font-semibold mb-2">Company Participation Report</h3>
                    <p class="mb-2">Analyze company engagement in placement activities.</p>
                    <a href="Rcompany.php" class="text-blue-600 hover:underline">Generate Report</a>
                </div>

                <div class="bg-gray-50 p-4 rounded-md">
                    <h3 class="text-lg font-semibold mb-2">Job Offer Trends</h3>
                    <p class="mb-2">Explore trends in job offers and acceptances.</p>
                    <a href="Rjobs.php" class="text-blue-600 hover:underline">Generate Report</a>
                </div>

                <div class="bg-gray-50 p-4 rounded-md">
                    <h3 class="text-lg font-semibold mb-2">Skill Gap Analysis</h3>
                    <p class="mb-2">Identify skill gaps between student profiles and job requirements.</p>
                    <a href="Rapplicants.php" class="text-blue-600 hover:underline">Generate Report</a>
                </div>
                <div class="bg-gray-50 p-4 rounded-md">
                    <h3 class="text-lg font-semibold mb-2">Selected Student</h3>
                    <p class="mb-2">the Students that are selected.</p>
                    <a href="Rstatus.php" class="text-blue-600 hover:underline">Generate Report</a>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>