 
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306"; 

$conn = new mysqli($servername, $username, $password, $database, $port);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer List - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Portal</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="report.php" class="hover:text-blue-300">Back</a></li>
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Company List</h2>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-300">
                    <thead>
                        <tr class="bg-gray-100">
                            <th class="py-2 px-4 border-b text-left">Company</th>
                            <th class="py-2 px-4 border-b text-left">Contact Person</th>
                            <th class="py-2 px-4 border-b text-left">Mobile</th>
                            <th class="py-2 px-4 border-b text-left">Email</th>
                            <th class="py-2 px-4 border-b text-left">Area of Work</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                    $sql = " select * from employer_reg where Status='Confirm'";
// Execute query
$result = $conn->query($sql);
// Loop through each records 
while($row =  $result->fetch_assoc())
{
$Name=$row['CompanyName'];
$Cname=$row['ContactPerson'];
$Mobile=$row['Mobile'];
$Email=$row['Email'];
$Area=$row['Area_Work'];
?>
                            <tr class="hover:bg-gray-50">
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($Name) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($Cname) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($Mobile) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($Email) ?></td>
                                <td class="py-2 px-4 border-b"><?= htmlspecialchars($Area) ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            
           
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?= date("Y") ?> Placement Cell Portal. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>