<?php
session_start();
// Check if user is logged in and is an admin


$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

// Establish Connection with Database
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pending employers
$sql = "SELECT * FROM Employer_Reg WHERE Status='Pending'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employers - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Admin Panel</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="User.php" class="hover:text-blue-300">User</a></li>
                <li><a href="ManageJob.php" class="hover:text-blue-300">Manage Students</a></li>
                <li><a href="ManageEmployer.php" class="hover:text-blue-300">Manage Companies</a></li>
                <li><a href="report.php" class="hover:text-blue-300">Reports</a></li>
                <li><a href="News.php" class="hover:text-blue-300">News</a></li>
                <li><a href="Feedback.php" class="hover:text-blue-300">Feedback</a></li>
                <li><a href="Logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Manage Employers</h2>
            
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white">
                    <thead class="bg-blue-500 text-white">
                        <tr>
                            <th class="py-2 px-4 text-left">Id</th>
                            <th class="py-2 px-4 text-left">Company Name</th>
                            <th class="py-2 px-4 text-left">City</th>
                            <th class="py-2 px-4 text-left">Contact Person</th>
                            <th class="py-2 px-4 text-left">Detail</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr class='border-b hover:bg-gray-50'>";
                                echo "<td class='py-2 px-4'>" . htmlspecialchars($row['EmployerId']) . "</td>";
                                echo "<td class='py-2 px-4'>" . htmlspecialchars($row['CompanyName']) . "</td>";
                                echo "<td class='py-2 px-4'>" . htmlspecialchars($row['City']) . "</td>";
                                echo "<td class='py-2 px-4'>" . htmlspecialchars($row['ContactPerson']) . "</td>";
                                echo "<td class='py-2 px-4'><a href='DetailEmp.php?EmpId=" . $row['EmployerId'] . "' class='text-blue-600 hover:underline'>Detail</a></td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='py-2 px-4 text-center'>No pending employers found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-4 text-gray-600">
                <?php echo "Total " . $result->num_rows . " Records"; ?>
            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Admin Panel. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>