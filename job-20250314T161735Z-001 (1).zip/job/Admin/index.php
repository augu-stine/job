<?php
session_start();
// Check if user is logged in and is an admin

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Admin Panel</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "User" => "User.php",
                    "Manage Students" => "ManageJob.php",
                    "Manage Companies" => "ManageEmployer.php",
                    "Reports" => "report.php",
                    "News" => "News.php",
                    "Feedback" => "Feedback.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Welcome To Control Panel</h2>
            <div class="space-y-4 text-gray-600">
                <p class="font-georgia text-lg">
                    <span class="font-bold text-xl">W</span>e are delighted to welcome you to the Placement Cell Admin Panel. Your role as an administrator is pivotal in shaping the future careers of our students and fostering strong connections with prospective companies.
                </p>
                <p class="font-georgia text-lg">
                    As an admin, you have the power to streamline and optimize the placement process, ensuring a seamless experience for both students and recruiters. From managing job listings to coordinating interviews, your efforts contribute significantly to the success of our students and the reputation of our institution.
                </p>
            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Admin Panel. All rights reserved.</p>
        </div>
    </footer>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'georgia': ['Georgia', 'serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>