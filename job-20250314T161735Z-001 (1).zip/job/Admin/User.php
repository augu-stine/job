<?php
session_start();
// Check if user is logged in and is an admin

$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306";

// Establish Connection with Database
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user list
$sql = "SELECT * FROM User_Master";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Custom CSS for darker borders and shorter textboxes */
        input {
            border-color: #2d3748; /* Darker border (Tailwind's gray-800) */
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Admin Panel</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="User.php" class="hover:text-blue-300">User</a></li>
                <li><a href="ManageJob.php" class="hover:text-blue-300">Manage Students</a></li>
                <li><a href="ManageEmployer.php" class="hover:text-blue-300">Manage Companies</a></li>
                <li><a href="report.php" class="hover:text-blue-300">Reports</a></li>
                <li><a href="News.php" class="hover:text-blue-300">News</a></li>
                <li><a href="Feedback.php" class="hover:text-blue-300">Feedback</a></li>
                <li><a href="Logout.php" class="hover:text-blue-300">Logout</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">User Management</h2>
            
            <!-- Create New User Form -->
            <div class="mb-8">
                <h3 class="text-xl font-semibold mb-4">Create New User</h3>
                <form id="createUserForm" action="InsertUser.php" method="post" class="space-y-4">
                    <div>
                        <label for="txtUserName" class="block text-sm font-medium text-gray-700">User Name:</label>
                        <input type="text" id="txtUserName" name="txtUserName" required class="mt-1 block w-1/4 rounded-md border-2 border-gray-800 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                    </div>
                    <div>
                        <label for="txtPassword" class="block text-sm font-medium text-gray-700">Password:</label>
                        <input type="password" id="txtPassword" name="txtPassword" required class="mt-1 block w-1/4 rounded-md border-2 border-gray-800 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                    </div>
                    <div>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">Submit</button>
                    </div>
                </form>
            </div>

            <!-- User List -->
            <div>
                <h3 class="text-xl font-semibold mb-4">User List</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-blue-500 text-white">
                            <tr>
                                <th class="py-2 px-4 text-left">Id</th>
                                <th class="py-2 px-4 text-left">UserName</th>
                                <th class="py-2 px-4 text-left">Edit</th>
                                <th class="py-2 px-4 text-left">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr class='border-b hover:bg-gray-50'>";
                                    echo "<td class='py-2 px-4'>" . htmlspecialchars($row['UserId']) . "</td>";
                                    echo "<td class='py-2 px-4'>" . htmlspecialchars($row['UserName']) . "</td>";
                                    echo "<td class='py-2 px-4'><a href='EditUser.php?UserId=" . $row['UserId'] . "' class='text-blue-600 hover:underline'>Edit</a></td>";
                                    echo "<td class='py-2 px-4'><a href='DeleteUser.php?UserId=" . $row['UserId'] . "' class='text-red-600 hover:underline'>Delete</a></td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='4' class='py-2 px-4 text-center'>No users found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Admin Panel. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Simple form validation
        document.getElementById('createUserForm').addEventListener('submit', function(e) {
            var username = document.getElementById('txtUserName').value;
            var password = document.getElementById('txtPassword').value;
            
            if (username.trim() === '' || password.trim() === '') {
                e.preventDefault();
                alert('Please fill in all fields');
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
