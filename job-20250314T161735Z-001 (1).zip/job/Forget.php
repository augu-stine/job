<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:400,700&display=swap');
        body {
            font-family: 'Assistant', sans-serif;
            background: linear-gradient(45deg, #3498db, #8e44ad);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">PLACEMENT CELL</h1>
        <h2 class="text-2xl font-semibold mb-6 text-center text-gray-700">Forgot Password</h2>
        
        <form id="form2" method="post" action="ForPass.php" class="space-y-4">
            <div class="space-y-2">
                <label class="block text-sm font-medium text-gray-700">Select User:</label>
                <div class="flex space-x-4">
                    <label class="inline-flex items-center">
                        <input type="radio" name="rdUser" value="Student" id="rdUser_0" class="form-radio text-blue-600">
                        <span class="ml-2">Student</span>
                    </label>
                    <label class="inline-flex items-center">
                        <input type="radio" name="rdUser" value="Company" id="rdUser_1" class="form-radio text-blue-600">
                        <span class="ml-2">Company</span>
                    </label>
                </div>
            </div>
            
            <div>
                <input type="text" placeholder="Enter User Name" name="txtUserName" id="txtUserName" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-100 focus:border-blue-300">
            </div>
            
            <div>
                <select name="cmbQue" id="cmbQue" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-100 focus:border-blue-300">
                    <option>What is Your Pet Name?</option>
                    <option selected="selected">Who is Your Favourite Person?</option>
                    <option>What is the Name of Your First School?</option>
                </select>
            </div>
            
            <div>
                <input type="text" placeholder="Answer" name="txtAnswer" id="txtAnswer" required class="w-full px-3 py-2 placeholder-gray-300 border border-gray-300 rounded-md focus:outline-none focus:ring focus:ring-blue-100 focus:border-blue-300">
            </div>
            
            <div>
                <button type="submit" class="w-full px-3 py-4 text-white bg-blue-500 rounded-md focus:bg-blue-600 focus:outline-none">Submit</button>
            </div>
        </form>
        
        
        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-blue-600 hover:text-blue-800">Back to Home</a>
        </div>
    </div>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Assistant', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>