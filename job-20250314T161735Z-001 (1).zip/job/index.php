<?php
$news_items = [
    ['title' => 'TCS New Hiring', 'content' => 'TCS is hiring laterally and for freshers across various domains, offering job rotation and enrichment opportunities. With over 1,000 job openings in India, TCS iON provides professional courses with placement and NQT.'],
    ['title' => 'Amazon Hiring ', 'content' => 'Amazon is hiring now for warehouse jobs, delivery drivers, fulfillment center workers, store associates and many more hourly positions. Apply today!'],
    ['title' => 'Strada Services', 'content' => 'Multiple Job Openings: Strada Services LLC has 127 open jobs, according to their careers page. The company is hiring for various positions, including Electrician, Installer, and Manager.']
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen">
    <header class="bg-white shadow">
        <nav class="container mx-auto px-4 py-4 flex justify-between items-center">
            <a href="index.php" class="text-2xl font-bold text-blue-600">Placement Cell</a>
            <button id="menuToggle" class="md:hidden p-2 rounded-md hover:bg-gray-100">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
            <div id="menu" class="hidden md:flex flex-col md:flex-row absolute md:relative top-full left-0 right-0 bg-white md:bg-transparent p-4 md:p-0">
                
                <a href="Aboutus.php" class="text-gray-600 hover:text-gray-800 py-2 md:py-0 md:mr-4">About Us</a>
                <a href="Employer.php" class="text-gray-600 hover:text-gray-800 py-2 md:py-0 md:mr-4">Companies</a>
                <a href="JobSeeker.php" class="text-gray-600 hover:text-gray-800 py-2 md:py-0 md:mr-4">Students</a>
                <a href="News.php" class="text-gray-600 hover:text-gray-800 py-2 md:py-0 md:mr-4">Latest News</a>
                <a href="login.php" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">Login</a>
            </div>
        </nav>
    </header>

    <main class="flex-grow">
        <section class="bg-blue-50 py-16 px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
                Welcome to the<br>Placement Cell
            </h1>
            <p class="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
                Connecting talented students with leading companies for exciting career opportunities.
            </p>
            <div class="space-x-4">
    <a href="stdlogin.php?userType=Student" class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">For Students</a>
    <a href="cmpylogin.php?userType=Company" class="bg-white text-blue-600 px-4 py-2 rounded-md border border-blue-600 hover:bg-blue-50">For Companies</a>
</div>

        </section>

        <section class="py-16 px-4">
            <h2 class="text-3xl font-bold text-center mb-8">Latest News</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                <?php foreach ($news_items as $item): ?>
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <h3 class="text-xl font-semibold mb-2"><?php echo htmlspecialchars($item['title']); ?></h3>
                        <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($item['content']); ?></p>
                        <a href="/news" class="text-blue-600 hover:text-blue-800">Read more</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-8 px-4">
        <div class="container mx-auto text-center">
            <div class="space-x-4 mb-4">
                <a href="index.php" class="hover:text-white">Home</a>
                <a href="Aboutus.php" class="hover:text-white">About Us</a>
                <a href="Employer.php" class="hover:text-white">Companies</a>
                <a href="JobSeeker.php" class="hover:text-white">Students</a>
                <a href="News.php" class="hover:text-white">Latest News</a>
            </div>
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>

    <script>
        document.getElementById('menuToggle').addEventListener('click', function() {
            var menu = document.getElementById('menu');
            menu.classList.toggle('hidden');
        });
    </script>
</body>
</html>