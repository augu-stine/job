<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latest News - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Education" => "Education.php",
                    "Search Job" => "SearchJob.php",
                    "Status" => "Statusjob.php",
                    "Feedback" => "Feedback.php",
                    "Notifications" => "News.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Latest News</h2>

            <table class="w-full border-collapse text-left table-auto">
                <thead class="bg-blue-600 text-white">
                    <tr>
                        <th class="py-2 px-4">#</th>
                        <th class="py-2 px-4">News</th>
                        <th class="py-2 px-4">News Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "job1";
                    $port = "3306";

                    $conn = new mysqli($servername, $username, $password, $database, $port);
                    $sql = "SELECT * FROM News_Master ORDER BY NewsDate DESC";
                    $result = $conn->query($sql);

                    $count = 1;
                    while ($row = $result->fetch_assoc()) {
                        $News = $row['News'];
                        $NewsDate = $row['NewsDate'];
                    ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo $count++; ?></td>
                        <td class="py-2 px-4"><?php echo $News; ?></td>
                        <td class="py-2 px-4"><?php echo $NewsDate; ?></td>
                    </tr>
                    <?php
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-4">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Placement Cell. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>
