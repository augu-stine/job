<?php
if(!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Portal - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Education" => "Education.php",
                    "Search Job" => "SearchJob.php",
                    "Status" => "Statusjob.php",
                    "Feedback" => "Feedback.php",
                    "Notifications" => "News.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Welcome To Student Portal</h2>
            <div class="space-y-4 text-gray-600">
                <p class="font-georgia text-lg">
                    <span class="font-bold text-xl">C</span>ongratulations on taking the first step towards a successful career. We're here to support and guide you on your journey to exciting job opportunities.
                </p>
                <p class="font-georgia text-lg">
                    As you step into our Placement Cell Dashboard, you're embarking on a journey filled with endless possibilities. This platform serves as your gateway to a world of career advancement and professional growth.
                </p>
                <p class="font-georgia text-lg">
                    Engage with personalized career guidance, access exclusive job listings from top recruiters, and participate in industry-specific workshops and events.
                </p>
                <p class="font-georgia text-lg">
                    As you navigate through this platform, embrace the opportunities that await you, and seize the moment. Welcome to your Placement Cell—where your future begins today.
                </p>
            </div>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Student Portal. All rights reserved.</p>
        </div>
    </footer>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'georgia': ['Georgia', 'serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>
