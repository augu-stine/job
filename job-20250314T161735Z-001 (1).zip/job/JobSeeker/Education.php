<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Qualification - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Education" => "Education.php",
                    "Search Job" => "SearchJob.php",
                    "Status" => "Statusjob.php",
                    "Feedback" => "Feedback.php",
                    "Notifications" => "News.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Education Qualification</h2>

            <div class="bg-blue-50 p-4 rounded-lg mb-6">
                <h3 class="text-xl font-bold text-blue-800 mb-3">Create Educational Profile</h3>

                <form id="form1" method="post" action="InsertEdu.php">
                    <div class="mb-4">
                        <label for="cmbQual" class="block text-gray-700 font-bold">Select Degree:</label>
                        <select name="cmbQual" id="cmbQual" class="mt-1 block w-1/3 bg-white text-gray-800 border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300">
                            <option value="B.C.A">B.C.A</option>
                            <option value="M.C.A">M.C.A</option>
                            <option value="B.Sc.I.T">B.Sc.I.T</option>
                            <option value="B.Sc.C.S">B.Sc.C.S</option>
                            <option value="M.Sc.I.T">M.Sc.I.T</option>
                            <option value="M.Sc.C.S">M.Sc.C.S</option>
                            <option value="M.B.A">M.B.A</option>
                            <option value="B.B.A">B.B.A</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="txtOther" class="block text-gray-700 font-bold">Other Degree:</label>
                        <input type="text" name="txtOther" id="txtOther" class="mt-1 block w-1/3 bg-white text-gray-800 border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300" />
                    </div>

                    <div class="mb-4">
                        <label for="txtBoard" class="block text-gray-700 font-bold">University/Board Name:</label>
                        <input type="text" name="txtBoard" id="txtBoard" class="mt-1 block w-1/3 bg-white text-gray-800 border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300" required />
                    </div>

                    <div class="mb-4">
                        <label for="cmbYear" class="block text-gray-700 font-bold">Passing Year:</label>
                        <select name="cmbYear" id="cmbYear" class="mt-1 block w-1/3 bg-white text-gray-800 border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300">
                            <?php
                            for ($year = 2015; $year <= 2030; $year++) {
                                echo "<option value=\"$year\">$year</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="txtPer" class="block text-gray-700 font-bold">Percentage (%):</label>
                        <input type="text" name="txtPer" id="txtPer" class="mt-1 block w-1/3 bg-white text-gray-800 border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-300" required />
                    </div>

                    <div>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Submit</button>
                    </div>
                </form>
            </div>

            <div class="bg-blue-50 p-4 rounded-lg">
                <h3 class="text-xl font-bold text-blue-800 mb-3">Educational Profile</h3>
                <table class="table-auto w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b bg-blue-200">
                            <th class="px-4 py-2 text-gray-600">Degree</th>
                            <th class="px-4 py-2 text-gray-600">University</th>
                            <th class="px-4 py-2 text-gray-600">Passing Year</th>
                            <th class="px-4 py-2 text-gray-600">Percentage</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $ID = $_SESSION['ID'];
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $database = "job1";
                        $port = "3306";

                        // Establish Connection with Database
                        $conn = new mysqli($servername, $username, $password, $database, $port);

                        // Specify the query to execute
                        $sql = "SELECT * FROM JobSeeker_Education WHERE JobSeekId='" . $ID . "' ORDER BY PassingYear DESC";
                        $result = $conn->query($sql);

                        // Loop through each record
                        while ($row = $result->fetch_assoc()) {
                            $Degree = $row['Degree'];
                            $Univ = $row['University'];
                            $Passing = $row['PassingYear'];
                            $Per = $row['Percentage'];
                        ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?php echo $Degree; ?></td>
                            <td class="px-4 py-2"><?php echo $Univ; ?></td>
                            <td class="px-4 py-2"><?php echo $Passing; ?></td>
                            <td class="px-4 py-2"><?php echo $Per; ?></td>
                        </tr>
                        <?php
                        }

                        // Retrieve Number of records returned
                        $records = $result->num_rows;
                        ?>
                        <tr>
                            <td colspan="4" class="px-4 py-2 text-gray-700"><?php echo "Total " . $records . " Records"; ?></td>
                        </tr>
                        <?php
                        // Close the connection
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="bg-gray-800 text-gray-400 py-4">
        <div class="container mx-auto px-4 text-center">
            <p>&copy; <?php echo date("Y"); ?> Placement Cell Student Portal. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
