<?php
if (!isset($_SESSION)) {
    session_start();
}

function getSQLValueString($mysqli, $theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") {
    $theValue = $mysqli->real_escape_string($theValue);

    switch ($theType) {
        case "text":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;    
        case "long":
        case "int":
            $theValue = ($theValue != "") ? intval($theValue) : "NULL";
            break;
        case "double":
            $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
            break;
        case "date":
            $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
            break;
        case "defined":
            $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
            break;
    }
    return $theValue;
}

$currentPage = $_SERVER["PHP_SELF"];
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306"; 

$conn = new mysqli($servername, $username, $password, $database, $port);

// Queries for distinct values
$query_Recordset1 = "SELECT DISTINCT MinQualification FROM job_master";
$Recordset1 = $conn->query($query_Recordset1);

$query_Recordset4 = "SELECT DISTINCT CompanyName FROM job_master";
$Recordset4 = $conn->query($query_Recordset4);

$query_Recordset5 = "SELECT DISTINCT JobTitle FROM job_master";
$Recordset5 = $conn->query($query_Recordset5);

$colname_Recordset2 = isset($_POST['cmbQual']) ? $_POST['cmbQual'] : "-1";
$colname2_Recordset2 = isset($_POST['cmbCompany']) ? $_POST['cmbCompany'] : "-1";
$colname3_Recordset2 = isset($_POST['cmbArea']) ? $_POST['cmbArea'] : "-1";

$whereclause = "MinQualification='$colname_Recordset2' AND CompanyName='$colname2_Recordset2' AND JobTitle='$colname3_Recordset2'";

// Adjust whereclause based on empty selections
if ($colname_Recordset2 == "") {
    $whereclause = "CompanyName='$colname2_Recordset2' AND JobTitle='$colname3_Recordset2'";
}
if ($colname2_Recordset2 == "") {
    $whereclause = "MinQualification='$colname_Recordset2' AND JobTitle='$colname3_Recordset2'";
}
if ($colname3_Recordset2 == "") {
    $whereclause = "MinQualification='$colname_Recordset2' AND CompanyName='$colname2_Recordset2'";
}
if (!empty($colname_Recordset2) && empty($colname2_Recordset2) && empty($colname3_Recordset2)) {
    $whereclause = "MinQualification='$colname_Recordset2'";
} elseif (empty($colname_Recordset2) && !empty($colname2_Recordset2) && empty($colname3_Recordset2)) {
    $whereclause = "CompanyName='$colname2_Recordset2'";
} elseif (empty($colname_Recordset2) && empty($colname2_Recordset2) && !empty($colname3_Recordset2)) {
    $whereclause = "JobTitle='$colname3_Recordset2'";
}

$query_Recordset2 = sprintf("SELECT * FROM job_master WHERE $whereclause");
$Recordset2 = $conn->query($query_Recordset2);
$totalRows_Recordset2 = $Recordset2->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Job - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Education" => "Education.php",
                    "Search Job" => "SearchJob.php",
                    "Status" => "Statusjob.php",
                    "Feedback" => "Feedback.php",
                    "Notifications" => "News.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Search Job</h2>

            <form id="form1" method="post" action="SearchJob.php">
                <table class="w-full border-collapse">
                    <tr>
                        <td class="py-2"><strong>Select Qualification:</strong></td>
                        <td class="py-2">
                            <select name="cmbQual" id="cmbQual" class="border rounded p-2">
                                <option value="">Qualification</option>
                                <?php
                                while ($row_Recordset1 = $Recordset1->fetch_assoc()) {
                                    echo "<option value=\"{$row_Recordset1['MinQualification']}\">{$row_Recordset1['MinQualification']}</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Select Company Name:</strong></td>
                        <td class="py-2">
                            <select name="cmbCompany" id="cmbCompany" class="border rounded p-2">
                                <option value="">Company</option>
                                <?php
                                while ($row_Recordset4 = $Recordset4->fetch_assoc()) {
                                    echo "<option value=\"{$row_Recordset4['CompanyName']}\">{$row_Recordset4['CompanyName']}</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="py-2"><strong>Select Area of Work:</strong></td>
                        <td class="py-2">
                            <select name="cmbArea" id="cmbArea" class="border rounded p-2">
                                <option value="">Designation</option>
                                <?php
                                while ($row_Recordset5 = $Recordset5->fetch_assoc()) {
                                    echo "<option value=\"{$row_Recordset5['JobTitle']}\">{$row_Recordset5['JobTitle']}</option>";
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>&nbsp;</td>
                        <td class="py-2">
                            <input type="submit" name="button" id="button" value="Search" class="bg-blue-600 text-white rounded py-2 px-4 hover:bg-blue-700 cursor-pointer" />
                        </td>
                    </tr>
                </table>
            </form>

            <?php if ($totalRows_Recordset2 > 0): ?>
                <h3 class="text-xl font-bold mt-6">Search Results:</h3>
                <?php while ($row_Recordset2 = $Recordset2->fetch_assoc()): ?>
                    <table class="table-auto w-full text-left border-collapse mt-4 border">
                        <tr class="border-b">
                            <td class="py-2"><strong>JobId:</strong></td>
                            <td class="py-2"><?php echo $row_Recordset2['JobId']; ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-2"><strong>Company Name:</strong></td>
                            <td class="py-2"><?php echo $row_Recordset2['CompanyName']; ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-2"><strong>Job Title:</strong></td>
                            <td class="py-2"><?php echo $row_Recordset2['JobTitle']; ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-2"><strong>Min Qualification:</strong></td>
                            <td class="py-2"><?php echo $row_Recordset2['MinQualification']; ?></td>
                        </tr>
                        <tr class="border-b">
                            <td class="py-2"><strong>Job Description:</strong></td>
                            <td class="py-2"><?php echo $row_Recordset2['Description']; ?></td>
                        </tr>
                        <tr>
                             <td>&nbsp;</td>
                             <td><a href="Apply.php?JobId=<?php echo $row_Recordset2['JobId'];?>"><strong>Apply For Job</strong></a></td>
                        </tr>
                    </table>
                    <hr class="my-4">
                <?php endwhile; ?>
            <?php else: ?>
                <p class="mt-4 text-red-500">No job found matching your criteria.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-4">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Placement Cell. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
