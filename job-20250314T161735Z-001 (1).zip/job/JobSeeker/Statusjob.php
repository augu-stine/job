<?php
if (!isset($_SESSION)) {
    session_start();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "job1";
$port = "3306"; 

$conn = new mysqli($servername, $username, $password, $database, $port);

$sql = "SELECT job_master.JobId, job_master.CompanyName, job_master.JobTitle, application_master.Status, application_master.JobSeekId, application_master.Description
        FROM application_master, job_master 
        WHERE application_master.JobId=job_master.JobId AND application_master.JobSeekId='" . $_SESSION['ID'] . "'";

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status of Job - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Georgia&family=Inter:wght@400;500;600;700&display=swap');
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col">
    <header class="bg-blue-600 text-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold">Placement Cell Student Portal</h1>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 py-3">
            <ul class="flex flex-wrap space-x-6">
                <?php
                $menuItems = array(
                    "Home" => "index.php",
                    "Profile" => "Profile.php",
                    "Education" => "Education.php",
                    "Search Job" => "SearchJob.php",
                    "Status" => "Statusjob.php",
                    "Feedback" => "Feedback.php",
                    "Notifications" => "News.php",
                    "Logout" => "Logout.php"
                );

                foreach ($menuItems as $itemName => $itemLink) {
                    echo "<li><a href=\"$itemLink\" class=\"hover:text-blue-300\">$itemName</a></li>";
                }
                ?>
            </ul>
        </div>
    </nav>

    <!-- Main Content Area -->
    <main class="flex-grow container mx-auto px-4 py-8">
        <div class="bg-white shadow-md rounded-lg p-6">
            <h2 class="text-2xl font-bold mb-6 text-gray-800">Status of Job Applications</h2>

            <?php if ($result->num_rows > 0): ?>
                <table class="w-full border-collapse text-left table-auto">
                    <thead class="bg-blue-600 text-white">
                        <tr>
                            <th class="py-2 px-4">Company Name</th>
                            <th class="py-2 px-4">Job Title</th>
                            <th class="py-2 px-4">Status</th>
                            <th class="py-2 px-4">Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="border-b">
                                <td class="py-2 px-4"><?php echo $row['CompanyName']; ?></td>
                                <td class="py-2 px-4"><?php echo $row['JobTitle']; ?></td>
                                <td class="py-2 px-4"><?php echo $row['Status']; ?></td>
                                <td class="py-2 px-4"><?php echo $row['Description']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="mt-4 text-red-500">No job application records found.</p>
            <?php endif; ?>
        </div>
    </main>

    <footer class="bg-gray-800 text-white py-4">
        <div class="container mx-auto text-center">
            <p>&copy; 2024 Placement Cell. All Rights Reserved.</p>
        </div>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
