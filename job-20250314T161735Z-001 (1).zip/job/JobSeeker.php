<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Placed Students - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">
    <header class="bg-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold text-blue-600">Placement Cell</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white py-4">
        <div class="container mx-auto px-4">
            <ul class="flex space-x-6">
                <li><a href="index.php" class="hover:text-blue-300">Home</a></li>
                <li><a href="AboutUs.php" class="hover:text-blue-300">About Us</a></li>
                <li><a href="Employer.php" class="hover:text-blue-300">Companies</a></li>
                <li><a href="JobSeeker.php" class="hover:text-blue-300">Students</a></li>
                <li><a href="news.php" class="hover:text-blue-300">Latest News</a></li>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8 flex flex-col md:flex-row">
        <div class="w-full md:w-3/4 pr-0 md:pr-8">
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-2xl font-bold mb-4 border-b pb-2">Placed Students</h2>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white">
                        <thead class="bg-blue-600 text-white">
                            <tr>
                                <th class="py-2 px-4 text-left">Name</th>
                                <th class="py-2 px-4 text-left">Company</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            $database = "job1";
                            $port = "3306";

                            $conn = new mysqli($servername, $username, $password, $database, $port);
                            
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            $sql = "SELECT application_master.JobSeekId, application_master.JobId, 
                                    JobSeeker_Reg.JobSeekerName, job_master.CompanyName 
                                    FROM application_master 
                                    INNER JOIN JobSeeker_Reg ON application_master.JobSeekId = JobSeeker_Reg.JobSeekId 
                                    INNER JOIN job_master ON application_master.JobId = job_master.JobId 
                                    WHERE application_master.Status='Confirm'";

                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr class='border-b hover:bg-gray-50'>";
                                    echo "<td class='py-2 px-4'>" . htmlspecialchars($row['JobSeekerName']) . "</td>";
                                    echo "<td class='py-2 px-4'>" . htmlspecialchars($row['CompanyName']) . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='2' class='py-2 px-4 text-center'>No placed students found</td></tr>";
                            }
                            $conn->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <aside class="w-full md:w-1/4 mt-8 md:mt-0">
            <div class="bg-white shadow-md rounded-lg p-6">
                <h3 class="text-xl font-bold mb-4">Quick Links</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-blue-600 hover:underline">Career Resources</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Upcoming Events</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Job Listings</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Contact Us</a></li>
                </ul>
            </div>
        </aside>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-8 px-4">
        <div class="container mx-auto text-center">
            <div class="space-x-4 mb-4">
                <a href="index.php" class="hover:text-white">Home</a>
                <a href="AboutUs.php" class="hover:text-white">About Us</a>
                <a href="Employer.php" class="hover:text-white">Companies</a>
                <a href="JobSeeker.php" class="hover:text-white">Students</a>
                <a href="news.php" class="hover:text-white">Latest News</a>
            </div>
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>