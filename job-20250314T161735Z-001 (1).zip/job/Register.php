<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:400,700&display=swap');
        body {
            font-family: 'Assistant', sans-serif;
            background: linear-gradient(45deg, #3498db, #8e44ad);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">PLACEMENT CELL</h1>
        
        <p class="text-center mb-4 text-gray-600">Choose Registration Type</p>
        
        <div class="space-y-4">
            <a href="JobSeekerReg.php" class="block w-full bg-blue-500 text-white text-center py-2 rounded-md hover:bg-blue-600 transition duration-300">
                New Student Registration
            </a>
            
            <a href="EmployerReg.php" class="block w-full bg-green-500 text-white text-center py-2 rounded-md hover:bg-green-600 transition duration-300">
                New Company Registration
            </a>
        </div>
        
        <div class="mt-6 text-center">
            <a href="login.php" class="text-blue-500 hover:underline">Already have an account? Login here</a>
        </div>
        
        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-blue-600 hover:text-blue-800">Back to Home</a>
        </div>
    </div>

    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'sans': ['Assistant', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</body>
</html>