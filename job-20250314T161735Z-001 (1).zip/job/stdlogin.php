<?php
session_start();
include "sqldb.php";

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['txtUser']) && isset($_POST['txtPass'])) {
        $UserName = $_POST['txtUser'];
        $Password = $_POST['txtPass'];

        $conn = new mysqli($servername, $username, $password, $database, $port);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prevent SQL injection by escaping the input
        $UserName = $conn->real_escape_string($UserName);
        $Password = $conn->real_escape_string($Password);

        // Query to verify the student credentials
        $sql = "SELECT * FROM jobseeker_reg WHERE UserName='$UserName' AND Password='$Password' AND Status!='Pending'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Set session variables for the logged-in student
            $_SESSION['ID'] = $row['JobSeekId'];
            $_SESSION['Name'] = $row['JobSeekerName'];
            $_SESSION['UserType'] = 'student';
            // Redirect to the student dashboard
            header("location: JobSeeker/index.php");
            exit();
        } else {
            $error = "Wrong UserName or Password or admin has not approved your reg";
        }

        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:400,700&display=swap');
        body {
            font-family: 'Assistant', sans-serif;
            background: linear-gradient(45deg, #3498db, #8e44ad);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-lg shadow-md w-96">
        <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">Student Login</h1>

        <!-- Display error if there is any -->
        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <span class="block sm:inline"><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <!-- Student login form -->
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="space-y-4">
            <input type="text" placeholder="Username" class="w-full px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" id="txtUser" name="txtUser" required>
            <input type="password" placeholder="Password" class="w-full px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500" id="txtPass" name="txtPass" required>
            <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition duration-300">Login</button>
        </form>

        <!-- Links for new users and forgotten passwords -->
        <div class="mt-4 text-center">
            <a href="JobSeekerReg.php" class="text-blue-500 hover:underline">New User?</a>
        </div>
        <div class="mt-4 text-center">
            <a href="Forget.php" class="text-blue-500 hover:underline">Forgot Password?</a>
        </div>

        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-blue-600 hover:text-blue-800">Back to Home</a>
        </div>
    </div>

    <!-- Optional alert for error handling in JavaScript -->
    <script>
        <?php
        if ($error) {
            echo 'alert("' . $error . '");';
        }
        ?>
    </script>
</body>
</html>
