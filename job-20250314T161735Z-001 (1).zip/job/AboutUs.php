<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        body {
            font-family: 'Inter', sans-serif;
        }
        .content-box p {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="flex flex-col min-h-screen bg-gray-100">
    <header class="bg-white shadow">
        <div class="container mx-auto px-4 py-6">
            <h1 class="text-3xl font-bold text-blue-600">Placement Cell</h1>
        </div>
    </header>

    <nav class="bg-gray-800 text-white py-4">
        <div class="container mx-auto px-4">
            <ul class="flex space-x-6">
            <a href="index.php" class="hover:text-white">Home</a>
                <a href="AboutUs.php" class="hover:text-white">About Us</a>
                <a href="Employer.php" class="hover:text-white">Companies</a>
                <a href="JobSeeker.php" class="hover:text-white">Students</a>
                <a href="News.php" class="hover:text-white">Latest News</a>
            </ul>
        </div>
    </nav>

    <main class="flex-grow container mx-auto px-4 py-8 flex flex-col md:flex-row">
        <div class="w-full md:w-3/4 pr-0 md:pr-8">
            <div class="bg-white shadow-md rounded-lg p-6">
                <h2 class="text-2xl font-bold mb-4 border-b pb-2">About Us</h2>
                <div class="content-box space-y-4 text-lg font-serif">
                    <p>At our Placement Cell, we are dedicated to empowering students and facilitating their transition from academia to the professional world. Our mission is to bridge the gap between education and employment by providing comprehensive support, resources, and opportunities for our students to thrive in their chosen careers.</p>
                    
                    <p>With a commitment to excellence and innovation, our Placement Cell serves as a catalyst for fostering meaningful connections between students, recruiters, and the industry at large. Through a myriad of programs, workshops, and networking events, we strive to equip our students with the skills, knowledge, and confidence needed to succeed in today's competitive job market.</p>

                    <p>Our team of experienced professionals works tirelessly to cultivate strong partnerships with leading companies and organizations across various sectors. These partnerships not only enhance our students' access to diverse employment opportunities but also ensure that our curriculum remains relevant and aligned with industry standards.</p>

                    <p>At the heart of our Placement Cell is a steadfast dedication to student success. Whether it's providing career counseling, resume building assistance, or interview preparation, we are committed to supporting each student throughout their journey towards achieving their professional aspirations.</p>

                    <p>As we continue to evolve and adapt to the ever-changing landscape of the job market, we remain steadfast in our commitment to serving our students and fostering a culture of excellence, integrity, and lifelong learning.</p>

                    <p>Join us at the Placement Cell and embark on a journey towards a brighter and more promising future. Together, let's unlock your full potential and pave the way for a successful career ahead.</p>
                </div>
            </div>
        </div>

        <aside class="w-full md:w-1/4 mt-8 md:mt-0">
            <div class="bg-white shadow-md rounded-lg p-6">
                <h3 class="text-xl font-bold mb-4">Quick Links</h3>
                <ul class="space-y-2">
                    <li><a href="#" class="text-blue-600 hover:underline">Career Resources</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Upcoming Events</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Job Listings</a></li>
                    <li><a href="#" class="text-blue-600 hover:underline">Contact Us</a></li>
                </ul>
            </div>
        </aside>
    </main>

    <footer class="bg-gray-800 text-gray-400 py-8 px-4">
        <div class="container mx-auto text-center">
            <div class="space-x-4 mb-4">
                <a href="index.php" class="hover:text-white">Home</a>
                <a href="AboutUs.php" class="hover:text-white">About Us</a>
                <a href="Employer.php" class="hover:text-white">Companies</a>
                <a href="JobSeeker.php" class="hover:text-white">Students</a>
                <a href="News.php" class="hover:text-white">Latest News</a>
            </div>
            <p>&copy; <?php echo date("Y"); ?> Placement Cell. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>