<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration - Placement Cell</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Assistant:400,700&display=swap');
        body {
            font-family: 'Assistant', sans-serif;
            background: linear-gradient(45deg, #3498db, #8e44ad);
        }
    </style>
</head>
<body class="min-h-screen py-12">
    <div class="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
        <h1 class="text-3xl font-bold mb-6 text-center text-gray-800">PLACEMENT CELL</h1>
        <h2 class="text-2xl font-semibold mb-6 text-center text-gray-700">Student Registration Form</h2>
        
        <form action="JobSeekerInsert.php" method="post" enctype="multipart/form-data" id="form2" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label for="txtName" class="block text-sm font-medium text-gray-700">Student Name</label>
                    <input type="text" name="txtName" id="txtName" placeholder="Enter Student Name" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtAddress" class="block text-sm font-medium text-gray-700">Address</label>
                    <textarea name="txtAddress" id="txtAddress" placeholder="Enter Address" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50"></textarea>
                </div>
                <div>
                    <label for="txtCity" class="block text-sm font-medium text-gray-700">City</label>
                    <input type="text" name="txtCity" id="txtCity" placeholder="Enter City" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtEmail" class="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" name="txtEmail" id="txtEmail" placeholder="Enter Email" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtMobile" class="block text-sm font-medium text-gray-700">Mobile</label>
                    <input type="text" name="txtMobile" id="txtMobile" maxlength="10" placeholder="Enter Mobile Number" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="cmbGender" class="block text-sm font-medium text-gray-700">Gender</label>
                    <select name="cmbGender" id="cmbGender" class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div>
                    <label for="cmbQual" class="block text-sm font-medium text-gray-700">Course</label>
                    <select name="cmbQual" id="cmbQual" class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option value="B.C.A">B.C.A</option>
                        <option value="M.C.A">M.C.A</option>
                        <option value="B.Sc.I.T">B.Sc.I.T</option>
                        <option value="B.Sc.C.S">B.Sc.C.S</option>
                        <option value="M.Sc.I.T">M.Sc.I.T</option>
                        <option value="M.Sc.C.S">M.Sc.C.S</option>
                        <option value="M.B.A">M.B.A</option>
                        <option value="B.B.A">B.B.A</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div>
                    <label for="txtOther" class="block text-sm font-medium text-gray-700">Other Course</label>
                    <input type="text" name="txtOther" id="txtOther" placeholder="Enter Other Course" class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtBirthDate" class="block text-sm font-medium text-gray-700">Birth Date</label>
                    <input type="date" name="txtBirthDate" id="txtBirthDate" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtsupply" class="block text-sm font-medium text-gray-700">No. of Supplementary</label>
                    <input type="text" name="txtsupply" id="txtsupply" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtUserName" class="block text-sm font-medium text-gray-700">User Name</label>
                    <input type="text" name="txtUserName" id="txtUserName" placeholder="Enter User Name" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtPassword" class="block text-sm font-medium text-gray-700">Password</label>
                    <input type="password" name="txtPassword" id="txtPassword" placeholder="Enter Password" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="CPassword" class="block text-sm font-medium text-gray-700">Confirm Password</label>
                    <input type="password" name="CPassword" id="CPassword" placeholder="Confirm Password" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="cmbQue" class="block text-sm font-medium text-gray-700">Security Question</label>
                    <select name="cmbQue" id="cmbQue" class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                        <option>What is Your Pet Name?</option>
                        <option selected="selected">Who is Your Favourite Person?</option>
                        <option>What is the Name of Your First School?</option>
                    </select>
                </div>
                <div>
                    <label for="txtAnswer" class="block text-sm font-medium text-gray-700">Answer</label>
                    <input type="text" name="txtAnswer" id="txtAnswer" placeholder="Enter Answer" required class="mt-1 block w-full rounded-md border-black bg-white shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                </div>
                <div>
                    <label for="txtFile" class="block text-sm font-medium text-gray-700">Upload Resume</label>
                    <input type="file" name="txtFile" id="txtFile" required class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
                </div>
            </div>
            <div class="flex justify-center mt-6">
                <button type="submit" class="px-6 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Register</button>
            </div>
        </form>
        <div class="mt-6 text-center">
            <a href="stdlogin.php" class="text-blue-500 hover:underline">Already have an account? Login here</a>
        </div>
        
        <div class="mt-4 text-center">
            <a href="index.php" class="text-sm text-blue-600 hover:text-blue-800">Back to Home</a>
        </div>
    </div>
</body>
</html>
